Model created by Sniffer

Pack contains 32 free models:

basin
basin set
bath
bed
bed table
book case
book case casked
cabinet
case
casket
coffe table
double bed
freezer
keyboard
kitchen1
kitchen2
lamp
lamp small
lcd
lustre one
lustre three
lustre five
office chair
office table
picture
seat chair
seat double
seat triple
shower
table with chair
TV LCD
WC



These models is free for commercial or non-commercial use. Sale or unauthorized commercial distribution of these models in any form is prohibited. Please distribute the file only in it's original unmodified zipped format with copyright text intact.

Visit my model page on www.turbosquide.com

For custom 3D model contact:

Leos sniffer Janek
ljanek@seznam.com

or

leos@maxara.com

My personal web:
http://sniffer.animace.com

My resource web:
http://www.maxarea.com

*******

