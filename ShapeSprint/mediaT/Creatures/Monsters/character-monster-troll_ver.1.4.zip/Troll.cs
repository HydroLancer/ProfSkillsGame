datablock TSShapeConstructor(TrollDts)
{
   baseShape = "./Troll01.dts";
   sequence0 = "./troll_idle.dsq Idle";
   sequence1 = "./troll_run.dsq Run";
   sequence2 = "./troll_walk.dsq Walk";
   sequence3 = "./troll_attack01.dsq Attack01";
   sequence4 = "./troll_attack02.dsq Attack02";
   sequence5 = "./troll_death01.dsq Death01";
   sequence6 = "./troll_death02.dsq Death02";

};         
