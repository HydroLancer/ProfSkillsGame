
--------------------------------------------------------------

Jesus Pedrosa Vidal

Address:
C/ Claudio Coello 81 - 3� A ext.
28001 - Madrid
SPAIN

msn:  jesped@hotmail.com
yahoo:  jesped.geo@yahoo.com
icq: 126003458

http://www.geocities.com/jesped.geo

--------------------------------------------------------------

Fully textured seagull.
 
